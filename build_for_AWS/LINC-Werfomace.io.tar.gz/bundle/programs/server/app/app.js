var require = meteorInstall({"imports":{"startup":{"server":{"index.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// imports/startup/server/index.js                                                                          //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
// import { Mongo } from 'meteor/mongo'
//
// Accounts.onCreateUser(function(options, user) {
//    user.profile = options.profile || {};
//    user.profile.gender = options.gender;
//    user.profile.birth = options.birth;
//    user.profile.phone = options.phone;
//    user.profile.phoneAd = options.phoneAd;
//    user.profile.interest1 = options.interest1;
//    user.profile.interest2 = options.interest2;
//    return user;
// });
//
//
// Meteor.startup(function () {
//   smtp = {
//     // username: 'ngnlab2018@gmail.com',
//     // password: 'NGNNGN10',
//     // server:   'smtp.gmail.com',
//     username: 'ngnlab2018@gmail.com',
//     password: 'NGNNGN10',
//     server:   'smtp.sendgrid.net',
//     port: 587
//   }
//
//   process.env.MAIL_URL = 'smtp://' + encodeURIComponent(smtp.username) + ':' + encodeURIComponent(smtp.password) + '@' + encodeURIComponent(smtp.server) + ':' + smtp.port;
// });
//
// if (Meteor.isServer) {
//
//
//     const ClassList = new Mongo.Collection('class');
//     const userClassList = new Mongo.Collection('userClassList');
//
//     Meteor.publish('classInfo', function getClassInfo(classId){
//         return ClassList.find({"_id._str":classId});
//     });
//
//   Meteor.methods({
//     findIdFunction: function (username, birth, phone) {
//         let currentUserInfo = Meteor.users.findOne({"username":username, "profile.birth":birth, "profile.phone":phone});
//         if(currentUserInfo) return currentUserInfo["emails"][0].address;
//         else return "null";
//     },
//     findPwFunction: function (id, username, birth, pw) {
//         let currentUserInfo = Meteor.users.findOne({"emails.address":id, "username":username, "profile.birth":birth});
//         if(currentUserInfo && pw == "none") return true;
//         else if(currentUserInfo && pw != "none") Accounts.setPassword(currentUserInfo["_id"], pw);
//         else{
//             return false;
//         }
//         // try {
//         //     Accounts.sendResetPasswordEmail(currentUserInfo["_id"]);
//         //     return true;
//         // } catch (e) {
//         //     console.log(e);
//         //     return false;
//         // }
//     },
//     updateMyInfoFunction: function (id, username, gender, birth, hp, hp_ad, interest1, interest2) {
//         Meteor.users.update({"_id":id},{$set : {username:username, "profile.gender":gender, "profile.birth":birth, "profile.phone":hp, "profile.phoneAd":hp_ad, "profile.interest1":interest1, "profile.interest2":interest2}});
//     },
//     fetchClass: function (id) {
//         let data;
//         let result = [];
//         let row;
//         if(id=="none") {
//             data = ClassList.find({});
//             row = data.fetch();
//             result = [row[0].className, row[0].classDesc, row[0].image, row[1].className, row[1].classDesc, row[1].image, row[0]._id, row[1]._id];
//         }
//         else{
//             let target = new Mongo.ObjectID(id);
//             data = ClassList.findOne({_id:target});
//             result = [data.className, data.classDesc, data.content, data.date, data.image, data.professorName, data._id];
//         }
//         return result;
//     },
//     fetchClassList: function (condition) {
//         let data;
//         if(condition!="none"){
//             let query = ".*"+condition+".*";
//             data = ClassList.find({"className": {$regex : query}});
//         }
//         else {
//             data = ClassList.find({});
//         }
//         for(var i = 0; i < data.count(); i++){
//             return data.fetch()
//         }
//     },
//     fetchClassListWithID: function (condition, id) {
//         let data;
//         if(condition!="none"){
//             let query = ".*"+condition+".*";
//             data = ClassList.find({"className": {$regex : query}});
//         }
//         else {
//             data = ClassList.find({});
//         }
//         let result = [];
//         data = data.fetch();
//         for (var row in data) {
//             if (userClassList.find({classId:data[row]._id._str, userId:Accounts.userId()}).count()==0) {
//                 result.push(data[row]);
//             }
//         }
//         return result;
//     },
//     addClass: function (userId, classId) {
//         if(userClassList.find({"userId" : userId, "classId":classId}).count()==0){
//             let target = new Mongo.ObjectID(classId);
//             let classInfo = ClassList.findOne({_id:target});
//             let date = new Date();
//             let endDate = new Date();
//             endDate.setDate(date.getDate()+classInfo.date);
//             userClassList.insert({"userId" : userId, "classId":classId, "start":date, "end":endDate, "className" : classInfo.className, "classDate" : classInfo.date});
//             return "success";
//         }
//         else return "dup";
//     }
//   });
// }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"server":{"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// server/main.js                                                                                           //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.watch(require("/imports/startup/server"));
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJOzs7Ozs7Ozs7OztBQzFIQUEsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHlCQUFSLENBQWIsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXHJcbi8vXHJcbi8vIEFjY291bnRzLm9uQ3JlYXRlVXNlcihmdW5jdGlvbihvcHRpb25zLCB1c2VyKSB7XHJcbi8vICAgIHVzZXIucHJvZmlsZSA9IG9wdGlvbnMucHJvZmlsZSB8fCB7fTtcclxuLy8gICAgdXNlci5wcm9maWxlLmdlbmRlciA9IG9wdGlvbnMuZ2VuZGVyO1xyXG4vLyAgICB1c2VyLnByb2ZpbGUuYmlydGggPSBvcHRpb25zLmJpcnRoO1xyXG4vLyAgICB1c2VyLnByb2ZpbGUucGhvbmUgPSBvcHRpb25zLnBob25lO1xyXG4vLyAgICB1c2VyLnByb2ZpbGUucGhvbmVBZCA9IG9wdGlvbnMucGhvbmVBZDtcclxuLy8gICAgdXNlci5wcm9maWxlLmludGVyZXN0MSA9IG9wdGlvbnMuaW50ZXJlc3QxO1xyXG4vLyAgICB1c2VyLnByb2ZpbGUuaW50ZXJlc3QyID0gb3B0aW9ucy5pbnRlcmVzdDI7XHJcbi8vICAgIHJldHVybiB1c2VyO1xyXG4vLyB9KTtcclxuLy9cclxuLy9cclxuLy8gTWV0ZW9yLnN0YXJ0dXAoZnVuY3Rpb24gKCkge1xyXG4vLyAgIHNtdHAgPSB7XHJcbi8vICAgICAvLyB1c2VybmFtZTogJ25nbmxhYjIwMThAZ21haWwuY29tJyxcclxuLy8gICAgIC8vIHBhc3N3b3JkOiAnTkdOTkdOMTAnLFxyXG4vLyAgICAgLy8gc2VydmVyOiAgICdzbXRwLmdtYWlsLmNvbScsXHJcbi8vICAgICB1c2VybmFtZTogJ25nbmxhYjIwMThAZ21haWwuY29tJyxcclxuLy8gICAgIHBhc3N3b3JkOiAnTkdOTkdOMTAnLFxyXG4vLyAgICAgc2VydmVyOiAgICdzbXRwLnNlbmRncmlkLm5ldCcsXHJcbi8vICAgICBwb3J0OiA1ODdcclxuLy8gICB9XHJcbi8vXHJcbi8vICAgcHJvY2Vzcy5lbnYuTUFJTF9VUkwgPSAnc210cDovLycgKyBlbmNvZGVVUklDb21wb25lbnQoc210cC51c2VybmFtZSkgKyAnOicgKyBlbmNvZGVVUklDb21wb25lbnQoc210cC5wYXNzd29yZCkgKyAnQCcgKyBlbmNvZGVVUklDb21wb25lbnQoc210cC5zZXJ2ZXIpICsgJzonICsgc210cC5wb3J0O1xyXG4vLyB9KTtcclxuLy9cclxuLy8gaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG4vL1xyXG4vL1xyXG4vLyAgICAgY29uc3QgQ2xhc3NMaXN0ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NsYXNzJyk7XHJcbi8vICAgICBjb25zdCB1c2VyQ2xhc3NMaXN0ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VzZXJDbGFzc0xpc3QnKTtcclxuLy9cclxuLy8gICAgIE1ldGVvci5wdWJsaXNoKCdjbGFzc0luZm8nLCBmdW5jdGlvbiBnZXRDbGFzc0luZm8oY2xhc3NJZCl7XHJcbi8vICAgICAgICAgcmV0dXJuIENsYXNzTGlzdC5maW5kKHtcIl9pZC5fc3RyXCI6Y2xhc3NJZH0pO1xyXG4vLyAgICAgfSk7XHJcbi8vXHJcbi8vICAgTWV0ZW9yLm1ldGhvZHMoe1xyXG4vLyAgICAgZmluZElkRnVuY3Rpb246IGZ1bmN0aW9uICh1c2VybmFtZSwgYmlydGgsIHBob25lKSB7XHJcbi8vICAgICAgICAgbGV0IGN1cnJlbnRVc2VySW5mbyA9IE1ldGVvci51c2Vycy5maW5kT25lKHtcInVzZXJuYW1lXCI6dXNlcm5hbWUsIFwicHJvZmlsZS5iaXJ0aFwiOmJpcnRoLCBcInByb2ZpbGUucGhvbmVcIjpwaG9uZX0pO1xyXG4vLyAgICAgICAgIGlmKGN1cnJlbnRVc2VySW5mbykgcmV0dXJuIGN1cnJlbnRVc2VySW5mb1tcImVtYWlsc1wiXVswXS5hZGRyZXNzO1xyXG4vLyAgICAgICAgIGVsc2UgcmV0dXJuIFwibnVsbFwiO1xyXG4vLyAgICAgfSxcclxuLy8gICAgIGZpbmRQd0Z1bmN0aW9uOiBmdW5jdGlvbiAoaWQsIHVzZXJuYW1lLCBiaXJ0aCwgcHcpIHtcclxuLy8gICAgICAgICBsZXQgY3VycmVudFVzZXJJbmZvID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoe1wiZW1haWxzLmFkZHJlc3NcIjppZCwgXCJ1c2VybmFtZVwiOnVzZXJuYW1lLCBcInByb2ZpbGUuYmlydGhcIjpiaXJ0aH0pO1xyXG4vLyAgICAgICAgIGlmKGN1cnJlbnRVc2VySW5mbyAmJiBwdyA9PSBcIm5vbmVcIikgcmV0dXJuIHRydWU7XHJcbi8vICAgICAgICAgZWxzZSBpZihjdXJyZW50VXNlckluZm8gJiYgcHcgIT0gXCJub25lXCIpIEFjY291bnRzLnNldFBhc3N3b3JkKGN1cnJlbnRVc2VySW5mb1tcIl9pZFwiXSwgcHcpO1xyXG4vLyAgICAgICAgIGVsc2V7XHJcbi8vICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuLy8gICAgICAgICB9XHJcbi8vICAgICAgICAgLy8gdHJ5IHtcclxuLy8gICAgICAgICAvLyAgICAgQWNjb3VudHMuc2VuZFJlc2V0UGFzc3dvcmRFbWFpbChjdXJyZW50VXNlckluZm9bXCJfaWRcIl0pO1xyXG4vLyAgICAgICAgIC8vICAgICByZXR1cm4gdHJ1ZTtcclxuLy8gICAgICAgICAvLyB9IGNhdGNoIChlKSB7XHJcbi8vICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGUpO1xyXG4vLyAgICAgICAgIC8vICAgICByZXR1cm4gZmFsc2U7XHJcbi8vICAgICAgICAgLy8gfVxyXG4vLyAgICAgfSxcclxuLy8gICAgIHVwZGF0ZU15SW5mb0Z1bmN0aW9uOiBmdW5jdGlvbiAoaWQsIHVzZXJuYW1lLCBnZW5kZXIsIGJpcnRoLCBocCwgaHBfYWQsIGludGVyZXN0MSwgaW50ZXJlc3QyKSB7XHJcbi8vICAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh7XCJfaWRcIjppZH0seyRzZXQgOiB7dXNlcm5hbWU6dXNlcm5hbWUsIFwicHJvZmlsZS5nZW5kZXJcIjpnZW5kZXIsIFwicHJvZmlsZS5iaXJ0aFwiOmJpcnRoLCBcInByb2ZpbGUucGhvbmVcIjpocCwgXCJwcm9maWxlLnBob25lQWRcIjpocF9hZCwgXCJwcm9maWxlLmludGVyZXN0MVwiOmludGVyZXN0MSwgXCJwcm9maWxlLmludGVyZXN0MlwiOmludGVyZXN0Mn19KTtcclxuLy8gICAgIH0sXHJcbi8vICAgICBmZXRjaENsYXNzOiBmdW5jdGlvbiAoaWQpIHtcclxuLy8gICAgICAgICBsZXQgZGF0YTtcclxuLy8gICAgICAgICBsZXQgcmVzdWx0ID0gW107XHJcbi8vICAgICAgICAgbGV0IHJvdztcclxuLy8gICAgICAgICBpZihpZD09XCJub25lXCIpIHtcclxuLy8gICAgICAgICAgICAgZGF0YSA9IENsYXNzTGlzdC5maW5kKHt9KTtcclxuLy8gICAgICAgICAgICAgcm93ID0gZGF0YS5mZXRjaCgpO1xyXG4vLyAgICAgICAgICAgICByZXN1bHQgPSBbcm93WzBdLmNsYXNzTmFtZSwgcm93WzBdLmNsYXNzRGVzYywgcm93WzBdLmltYWdlLCByb3dbMV0uY2xhc3NOYW1lLCByb3dbMV0uY2xhc3NEZXNjLCByb3dbMV0uaW1hZ2UsIHJvd1swXS5faWQsIHJvd1sxXS5faWRdO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgICBlbHNle1xyXG4vLyAgICAgICAgICAgICBsZXQgdGFyZ2V0ID0gbmV3IE1vbmdvLk9iamVjdElEKGlkKTtcclxuLy8gICAgICAgICAgICAgZGF0YSA9IENsYXNzTGlzdC5maW5kT25lKHtfaWQ6dGFyZ2V0fSk7XHJcbi8vICAgICAgICAgICAgIHJlc3VsdCA9IFtkYXRhLmNsYXNzTmFtZSwgZGF0YS5jbGFzc0Rlc2MsIGRhdGEuY29udGVudCwgZGF0YS5kYXRlLCBkYXRhLmltYWdlLCBkYXRhLnByb2Zlc3Nvck5hbWUsIGRhdGEuX2lkXTtcclxuLy8gICAgICAgICB9XHJcbi8vICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuLy8gICAgIH0sXHJcbi8vICAgICBmZXRjaENsYXNzTGlzdDogZnVuY3Rpb24gKGNvbmRpdGlvbikge1xyXG4vLyAgICAgICAgIGxldCBkYXRhO1xyXG4vLyAgICAgICAgIGlmKGNvbmRpdGlvbiE9XCJub25lXCIpe1xyXG4vLyAgICAgICAgICAgICBsZXQgcXVlcnkgPSBcIi4qXCIrY29uZGl0aW9uK1wiLipcIjtcclxuLy8gICAgICAgICAgICAgZGF0YSA9IENsYXNzTGlzdC5maW5kKHtcImNsYXNzTmFtZVwiOiB7JHJlZ2V4IDogcXVlcnl9fSk7XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICAgIGVsc2Uge1xyXG4vLyAgICAgICAgICAgICBkYXRhID0gQ2xhc3NMaXN0LmZpbmQoe30pO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgZGF0YS5jb3VudCgpOyBpKyspe1xyXG4vLyAgICAgICAgICAgICByZXR1cm4gZGF0YS5mZXRjaCgpXHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgfSxcclxuLy8gICAgIGZldGNoQ2xhc3NMaXN0V2l0aElEOiBmdW5jdGlvbiAoY29uZGl0aW9uLCBpZCkge1xyXG4vLyAgICAgICAgIGxldCBkYXRhO1xyXG4vLyAgICAgICAgIGlmKGNvbmRpdGlvbiE9XCJub25lXCIpe1xyXG4vLyAgICAgICAgICAgICBsZXQgcXVlcnkgPSBcIi4qXCIrY29uZGl0aW9uK1wiLipcIjtcclxuLy8gICAgICAgICAgICAgZGF0YSA9IENsYXNzTGlzdC5maW5kKHtcImNsYXNzTmFtZVwiOiB7JHJlZ2V4IDogcXVlcnl9fSk7XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICAgIGVsc2Uge1xyXG4vLyAgICAgICAgICAgICBkYXRhID0gQ2xhc3NMaXN0LmZpbmQoe30pO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgICBsZXQgcmVzdWx0ID0gW107XHJcbi8vICAgICAgICAgZGF0YSA9IGRhdGEuZmV0Y2goKTtcclxuLy8gICAgICAgICBmb3IgKHZhciByb3cgaW4gZGF0YSkge1xyXG4vLyAgICAgICAgICAgICBpZiAodXNlckNsYXNzTGlzdC5maW5kKHtjbGFzc0lkOmRhdGFbcm93XS5faWQuX3N0ciwgdXNlcklkOkFjY291bnRzLnVzZXJJZCgpfSkuY291bnQoKT09MCkge1xyXG4vLyAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goZGF0YVtyb3ddKTtcclxuLy8gICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4vLyAgICAgfSxcclxuLy8gICAgIGFkZENsYXNzOiBmdW5jdGlvbiAodXNlcklkLCBjbGFzc0lkKSB7XHJcbi8vICAgICAgICAgaWYodXNlckNsYXNzTGlzdC5maW5kKHtcInVzZXJJZFwiIDogdXNlcklkLCBcImNsYXNzSWRcIjpjbGFzc0lkfSkuY291bnQoKT09MCl7XHJcbi8vICAgICAgICAgICAgIGxldCB0YXJnZXQgPSBuZXcgTW9uZ28uT2JqZWN0SUQoY2xhc3NJZCk7XHJcbi8vICAgICAgICAgICAgIGxldCBjbGFzc0luZm8gPSBDbGFzc0xpc3QuZmluZE9uZSh7X2lkOnRhcmdldH0pO1xyXG4vLyAgICAgICAgICAgICBsZXQgZGF0ZSA9IG5ldyBEYXRlKCk7XHJcbi8vICAgICAgICAgICAgIGxldCBlbmREYXRlID0gbmV3IERhdGUoKTtcclxuLy8gICAgICAgICAgICAgZW5kRGF0ZS5zZXREYXRlKGRhdGUuZ2V0RGF0ZSgpK2NsYXNzSW5mby5kYXRlKTtcclxuLy8gICAgICAgICAgICAgdXNlckNsYXNzTGlzdC5pbnNlcnQoe1widXNlcklkXCIgOiB1c2VySWQsIFwiY2xhc3NJZFwiOmNsYXNzSWQsIFwic3RhcnRcIjpkYXRlLCBcImVuZFwiOmVuZERhdGUsIFwiY2xhc3NOYW1lXCIgOiBjbGFzc0luZm8uY2xhc3NOYW1lLCBcImNsYXNzRGF0ZVwiIDogY2xhc3NJbmZvLmRhdGV9KTtcclxuLy8gICAgICAgICAgICAgcmV0dXJuIFwic3VjY2Vzc1wiO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgICBlbHNlIHJldHVybiBcImR1cFwiO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0pO1xyXG4vLyB9XHJcbiIsImltcG9ydCAnL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXInO1xyXG5cclxuIl19
